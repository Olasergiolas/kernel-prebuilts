#ifndef _ASM_ARM_VMALLOC_H
#define _ASM_ARM_VMALLOC_H

#endif /* _ASM_ARM_VMALLOC_H */
