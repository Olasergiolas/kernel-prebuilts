#ifndef _ASM_FB_H_
#define _ASM_FB_H_

#include <asm-generic/fb.h>

#endif /* _ASM_FB_H_ */
