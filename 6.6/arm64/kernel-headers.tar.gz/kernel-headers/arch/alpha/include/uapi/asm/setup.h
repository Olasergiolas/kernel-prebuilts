/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI__ALPHA_SETUP_H
#define _UAPI__ALPHA_SETUP_H

#define COMMAND_LINE_SIZE	256

#endif /* _UAPI__ALPHA_SETUP_H */
