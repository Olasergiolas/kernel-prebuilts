/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ALPHA_COMPILER_H
#define __ALPHA_COMPILER_H

#include <uapi/asm/compiler.h>

#endif /* __ALPHA_COMPILER_H */
